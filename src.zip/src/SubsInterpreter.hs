module SubsInterpreter
  ( runProg
  , Error (..)
  , Value(..)
  ) where

import Interpreter.Impl
  ( runProg
  , Error (..)
  , Value(..)
  )
