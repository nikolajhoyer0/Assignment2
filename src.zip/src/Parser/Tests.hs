module Parser.Tests where

import Parser.Impl
import Test.Tasty
